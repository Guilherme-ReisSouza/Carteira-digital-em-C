#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "include/menu.h"
#include "include/user.h"
#include "include/adicionar.h"
#include "include/remover.h"
#include "include/categoria.h"
#include "include/extrato.h"


struct Usuario{
    char nome[200];
    long long int CPF ;
    float saldo;
    int senha;
};

int main() {
    struct Usuario u;
    FILE *p_user = fopen("user.html", "r");;

    if(p_user == NULL)
    {
        p_user = fopen("user.html", "a+");
        criaUsuario(p_user, &(u));
        main();
    }
    else {
        while (1) {
            struct Usuario a = retornaUsuario();
            FILE *pont_arq;
            pont_arq = fopen("carteira.txt", "a+");
            printf("Seja bem-vindo(a) %s\n",a.nome);
            int op = menu();
            if (op == 1) {
                Adicionar(pont_arq, p_user, &a);
            } else if (op == 2) {
                imprimeExtrato(fopen("carteira.txt", "r"));
            } else if (op == 3) {
                printf("=================================\n");
                printf("Seu saldo atual é: %f  |\n", a.saldo);
                printf("=================================\n");
            } else if (op == 4) {
                Remover(p_user);
                p_user = fopen("user.html", "a+");
            }else if(op == 5){
                Extrato(fopen("carteira.txt", "r"));
                printf("\n");
                printf("Seu saldo atual é: %f   \n", a.saldo);
                printf("=================================\n");
                printf("\n");

              }
            else if (op == 0) {
                printf("Fechando o sistema....\n");
                fclose(p_user);
                fclose(pont_arq);
                break;
            } else {
                printf("Operacao Invalida, fechando o sistema....\n");
                fclose(p_user);
                fclose(pont_arq);
                break;
            }
        }
    }

    return 0;
}