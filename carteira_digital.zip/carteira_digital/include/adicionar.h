#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef ADICIONAR_H_
#define ADICIONAR_H_

void tiraEnter(char *s);
void Adicionar (FILE *p, FILE* p_user, struct Usuario* u);

#endif