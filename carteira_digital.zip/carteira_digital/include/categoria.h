#ifndef CATEGORIA_H_
#define CATEGORIA_H_

void ImprimeCategoria(FILE *file, char* categoria);
void Anual(FILE *carteira, char *ano);
void ImprimeCategoriaMes(FILE *file);
void Imprime(FILE *file);

#endif