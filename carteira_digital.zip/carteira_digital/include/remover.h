#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#ifndef REMOVER_H_
#define REMOVER_H_

void Remover( FILE *user);
void RemoverTudo();

#endif