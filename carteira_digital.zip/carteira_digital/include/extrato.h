#ifndef EXTRATO_H_
#define EXTRATO_H_

void Extrato(FILE *file);
void imprimeExtrato(FILE *file);

#endif