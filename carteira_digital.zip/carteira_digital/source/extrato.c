#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "../include/extrato.h"

//Imprimi extrato bancário do usuário
void Extrato(FILE* arquivo){

  char data[20];
  float valor;
  char categoria[20];
  int i, result = 0;

  while ((result = fscanf(arquivo, "%s %f %s", data, &valor, categoria)) != EOF)
  {
    
    if (result == 3)
    {
      i++;
      if (valor > 0){
        printf("Data: %s +%f %s\n", data, valor, categoria);
      }else{
        printf("Data: %s %f %s\n", data, valor, categoria);
      }
    }
  }

  fclose(arquivo);
}

void imprimeExtrato(FILE* arquivo){
  char data[20];
  float valor;
  char categoria[20];
  int i, result = 0;

  FILE *relatorio = fopen("relatorio.html", "w");
  fprintf(relatorio, "<!DOCTYPE <html> <head> <meta charset='UTF-8'> <title>Relatório</title> <link rel = 'stylesheet' href = 'main.css'> </head> <body> <header> <h1>Relatório de transações</h1> </header> <div> <table class='products-table'> <thead> <tr> <th>Data da transação</th> <th>Valor</th> <th>Categoria</th> </tr> </thead> <tbody>");
  while ((result = fscanf(arquivo, "%s %f %s", data, &valor, categoria)) != EOF)
  {
    if (result == 3)
    {
      i++;
      if (valor > 0){
        fprintf(relatorio, "<tr><td> %s </td>\n", data);
        fprintf(relatorio, "<td> +%.2f </td>\n", valor);
        fprintf(relatorio, "<td> %s </td></tr>\n", categoria);
      }else{
        fprintf(relatorio, "<tr><td> %s </td>\n", data);
        fprintf(relatorio, "<td> %.2f </td>\n", valor);
        fprintf(relatorio, "<td> %s </td></tr>\n", categoria);
      }

    }
  }
  fprintf(relatorio, " </tbody> </table> </div> </body> </html>");
  fclose(arquivo);
  fclose(relatorio);

}

