#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <locale.h>

#include "../include/menu.h"

//Aparencia MENU INICIAL
int menu(){
    setlocale(LC_ALL,"Portuguese_Brasil");
    printf("---------------------------------------------|\n");
    printf("-------------- Menu de opções ---------------|\n");
    printf("=============================================|\n");
    printf("1 - Adicionar Receita/Gasto                  |\n");
    printf("2 - Relatório de Movimentações da conta      |\n");
    printf("3 - Saldo da conta                           |\n");
    printf("4 - Excluir dados                            |\n");
    printf("5 - Extrato da conta                         |\n");
    printf("0 - Sair                                     |\n");
    printf("==============================================\n");
    int operacao;
    printf("Opção desejada => ");
    scanf(" %d",&operacao);
    return operacao;
}