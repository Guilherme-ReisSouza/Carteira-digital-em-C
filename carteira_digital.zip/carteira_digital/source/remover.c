#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "../include/remover.h"
#include "../include/categoria.h"

void RemoverTudo(){
    remove("user.html");

    printf("Dados de usuario deletados\n");
    exit(0);

}

void Remover(FILE *user){

    int op=0;
    printf("\n");
    printf("Você tem certeza?\n");
    printf("---------------------------------------\n");
    printf("1 - Voltar ao menu\n");
    printf("2 - Excluir dados de usuário\n");    
    printf("---------------------------------------\n");
    printf("Opção desejada => ");
    scanf(" %d", &op);
    if (op == 1) {
       printf("Voltando ao menu....\n");
    } else if (op == 2) {
        RemoverTudo();
    }
}