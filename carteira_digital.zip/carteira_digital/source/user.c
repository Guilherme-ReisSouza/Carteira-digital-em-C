#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "../include/user.h"
#include "../include/adicionar.h"

struct Usuario{
    char nome[200];
    long long int CPF ;
    float saldo;
    int senha;
};


struct Usuario retornaUsuario() {
    struct Usuario u;

    char nome[100];
    long long int CPF ;
    float saldo;
    int senha;

    FILE *fileUser = fopen("user.html", "r+");

    fgets(nome, 100 ,fileUser);
    tiraEnter(nome);
    fscanf(fileUser,"%lld",&CPF);
    fscanf(fileUser,"%f",&saldo);
    fscanf(fileUser,"%d",&senha);

    strcpy(u.nome, nome);
    u.CPF = CPF;
    u.saldo = saldo;
    u.senha = senha;

    return u;
}

void criaUsuario(FILE *p, struct Usuario* u){

    printf("-----------------------------------------\n");
    printf("         Vamos criar a sua conta!        \n");
    printf("=========================================\n");
    printf("Qual o seu nome?\n");
    fgets(u->nome, 200, stdin);
    fflush(stdin);
    printf("-----------------------------------------\n");
    printf("Qual seu CPF? (sem pontos/traços)\n");
    scanf("%lld", &u->CPF);
    fflush(stdin);
    u->saldo = 0.0;
    printf("-----------------------------------------\n");
    printf("Qual a sua senha? (Insira apenas numeros)\n");
    fflush(stdin);
    scanf("%d", &u->senha);
    fflush(stdin);
    printf("-----------------------------------------\n");

    fprintf(p, "%s", u->nome);
    fprintf(p, "%lld\n", u->CPF);
    fprintf(p, "%f\n", u->saldo);
    fprintf(p, "%d\n", u->senha);
    fprintf(p, "<DOCTYPE HTML> %d\n", u->senha);
    fprintf(p,"<!DOCTYPE html>");
    fprintf(p,"<html>");
    fprintf(p,"<head><meta charset='UTF-8'><title>Usuário</title></head><body class='body' align='center'> <a class='a'>Usuário</a><br><br><br><br>");
    fprintf(p,"<table border='2' align='left' class = 't1' ><tr class='e'><td>Dados:</td><td>Valor</td><td>Data</td></tr>");
    fclose(p);
}

void atualizarUser(float r,struct Usuario* u,FILE* p_user){
    u->saldo += r;
    remove("user.html");

    p_user = fopen("user.html", "a");

    fprintf(p_user, "%s\n", u->nome);
    fprintf(p_user, "%lld\n", u->CPF);
    fprintf(p_user, "%f\n", u->saldo);
    fprintf(p_user, "%d\n", u->senha);
    fprintf(p_user, "<DOCTYPE HTML> %d\n", u->senha);
    fclose(p_user);


}