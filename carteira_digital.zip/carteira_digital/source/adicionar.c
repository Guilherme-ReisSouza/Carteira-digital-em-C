#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "../include/user.h"
#include "../include/menu.h"

struct Usuario{
    char nome[200];
    long long int CPF ;
    float saldo;
    int senha;
};

struct Data{
    int dia;
    int mes;
    int ano;
};

struct Receita{
    struct Data data;
    float valor;
    char categoria[200];
};

void tiraEnter(char *s){
    int i;
    for (i = 0; s[i] != '\n' ; ++i) {
    }
    s[i] = 0;
}

void Adicionar (FILE *p, FILE* p_user, struct Usuario* u) {
    struct Receita r;
    int senha;
    printf("-------------------------------\n");
    printf("Insira sua senha para seguir:\n");
    scanf("%d", &senha);

    if (senha == (u->senha)) {
        printf("Senha correta!\n");
        int op;
        printf("Escolha qual ação deseja executar:\n");
        printf("1 - Adicionar Receita\n");
        printf("2 - Adicionar Despesa\n");
        printf("Insira a opção => ");
        scanf(" %d", &op);
        while (op > 2 || op <= 0) {
          printf("Digite um comando valido!\n");
          scanf("%d", &op);
        }
        printf("-------------------------------\n");

        printf("Qual o valor? \n");
        float valor;
        scanf(" %f", &valor);
        while (valor <= 0) {
            printf("Digite um valor valido!\n");
            scanf("%f", &valor);
        }
        printf("Data de referência? (dd mm aaaa) - Sem caracteres barra/traço\n");
        int dia, mes, ano;
        scanf("%d %d %d", &dia, &mes, &ano);
        while ((dia <= 0 || dia >= 32) || (mes <= 0 || mes >= 13) || (ano <= 0 || ano > 2021)) {
            puts("Digite uma data valida\n");
            scanf("%d %d %d", &dia, &mes, &ano);
        }
        fflush(stdin);
        puts("Insira uma categoria: (Moradia, Estudos, Transporte, Alimentacao, Outros)\n");
        char categoria[200];
        fflush(stdin);
        fgets(categoria, 200, stdin);
        tiraEnter(categoria);

        while ((strcmp(categoria, "Moradia") !=0) && (strcmp(categoria, "Estudos") != 0) &&
               (strcmp(categoria, "Alimentacao") != 0) && (strcmp(categoria, "Transporte") != 0) &&
               (strcmp(categoria, "Outros") != 0))
        {
            printf("Digite uma categoria entre as opções\n");
            fgets(categoria, 200, stdin);
            tiraEnter(categoria);
        }

        r.valor = valor;
        r.data.dia = dia;
        r.data.mes = mes;
        r.data.ano = ano;
        strcpy(r.categoria, categoria);


        fprintf(p, "%d/%d/%d", r.data.dia, r.data.mes, r.data.ano);
        if (op == 1) {
            fprintf(p, "%s", " +");
            atualizarUser(r.valor, u, p_user);
        } else if (op == 2) {
            fprintf(p, "%s", " -");
            atualizarUser(-r.valor, u, p_user);

        }
        fprintf(p, "%f", r.valor);
        fprintf(p, " %s\n", r.categoria);
        
        printf("Ação realizada com sucesso !\n");
        printf("---------------------------------\n");
        fclose(p);


    } else {
        printf("========================\n");
        printf("As senhas não coincidem!\n");
        printf("========================\n");
    }
}